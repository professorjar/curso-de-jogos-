# Pygame
Games and animations that i did using pygame library

1. DINO GAME [Link to the video](https://www.youtube.com/watch?v=slV0hbIJGGk&t=27s)

![Alt Text](https://github.com/joaotinti75/Pygame/blob/master/gif_dino.gif)

2. MATRIX ANIMATION
[Link to the video](https://www.youtube.com/watch?v=ZsQRWa-ek4k&t=326s)
![Alt Text](https://github.com/joaotinti75/Pygame/blob/master/matrixgif.gif)

